----------------------------------------------------------------------
-- CLINIC ANALYTICAL REPORTS & KPIs SCRIPT
----------------------------------------------------------------------
USE AlaaPearlDentalComplexDB;
GO

/*
===================================================================
[REPORT 1] TOP DOCTOR REVENUE & PERFORMANCE REPORT
Purpose: Evaluates doctor efficiency by counting total patient 
         appointments and computing the total net revenue generated.
===================================================================
*/
-- (Query Definition is placed in the Execution Section at the bottom)

/*
===================================================================
[REPORT 2] HIGH-RISK PATIENTS MEDICAL TRACKER
Purpose: Filters and displays patients with high-risk conditions 
         (e.g., Diabetes, Heart Conditions) along with their total 
         clinic visits to ensure clinical safety during surgeries.
===================================================================
*/
-- (Query Definition is placed in the Execution Section at the bottom)

/*
===================================================================
[REPORT 3] INVENTORY LOW-STOCK & CRITICAL ALERT REPORT
Purpose: Monitors the medical warehouse by flagging supplies that 
         have dropped below the absolute minimum safety threshold.
===================================================================
*/
-- (Query Definition is placed in the Execution Section at the bottom)

/*
===================================================================
[REPORT 4] CLINIC OPERATIONS & NURSE ASSISTANCE REPORT
Purpose: Tracks clinical room utilization and analyzes how many times 
         nurses assisted doctors during scheduled operations.
===================================================================
*/
-- (Query Definition is placed in the Execution Section at the bottom)


----------------------------------------------------------------------
-- EXECUTION SECTION: RUNNING ALL ANALYTICAL REPORTS
----------------------------------------------------------------------

-- [1] Run Top Doctor Revenue & Performance Report
SELECT 
    D.Staff_ID AS Doctor_ID,
    CONCAT(S.First_Name, ' ', S.Last_Name) AS Doctor_Name,
    COUNT(A.App_ID) AS Total_Appointments,
    SUM(B.Net_Amount) AS Total_Revenue_Generated
FROM Doctor D
JOIN Staff S ON D.Staff_ID = S.Staff_ID
JOIN Appointment A ON D.Staff_ID = A.Doctor_ID
JOIN Billing B ON A.App_ID = B.Appointment_ID
GROUP BY D.Staff_ID, S.First_Name, S.Last_Name
ORDER BY Total_Revenue_Generated DESC;

-- [2] Run High-Risk Patients Medical Tracker
SELECT 
    P.Patient_ID,
    CONCAT(P.First_Name, ' ', P.Last_Name) AS Patient_Name,
    P.City,
    MC.Condition_Name,
    MC.Risk_Level,
    COUNT(A.App_ID) AS Total_Visits
FROM Patient P
JOIN Patient_Medical_Conditions PMC ON P.Patient_ID = PMC.Patient_ID
JOIN Medical_Conditions MC ON PMC.Condition_ID = MC.Condition_ID
LEFT JOIN Appointment A ON P.Patient_ID = A.Patient_ID
WHERE MC.Risk_Level = 'High'
GROUP BY P.Patient_ID, P.First_Name, P.Last_Name, P.City, MC.Condition_Name, MC.Risk_Level;

-- [3] Run Inventory Low-Stock & Critical Alert Report
SELECT 
    Item_ID,
    Item_Name,
    Quantity_In_Stock,
    Quantity_In_Min,
    Unit_Price,
    CASE 
        WHEN Quantity_In_Stock <= Quantity_In_Min THEN 'CRITICAL: Reorder Immediately!'
        ELSE 'Safe'
    END AS Stock_Status
FROM Medical_Supplies_Inventory
WHERE Quantity_In_Stock <= Quantity_In_Min
ORDER BY Quantity_In_Stock ASC;

-- [4] Run Clinic Operations & Nurse Assistance Report
SELECT 
    N.Staff_ID AS Nurse_ID,
    CONCAT(NS.First_Name, ' ', NS.Last_Name) AS Nurse_Name,
    N.Clinic_Type AS Nurse_Specialty,
    COUNT(DISTINCT DNA.Doctor_ID) AS Total_Doctors_Assisted,
    COUNT(DISTINCT A.Room_ID) AS Total_Clinic_Rooms_Utilized
FROM Nurse N
JOIN Staff NS ON N.Staff_ID = NS.Staff_ID
LEFT JOIN Doctor_Nurse_Assists DNA ON N.Staff_ID = DNA.Nurse_ID
LEFT JOIN Appointment A ON DNA.Doctor_ID = A.Doctor_ID
GROUP BY N.Staff_ID, NS.First_Name, NS.Last_Name, N.Clinic_Type;
GO