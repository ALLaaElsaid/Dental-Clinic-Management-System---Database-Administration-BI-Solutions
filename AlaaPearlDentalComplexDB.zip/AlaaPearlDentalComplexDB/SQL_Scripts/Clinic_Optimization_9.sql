----------------------------------------------------------------------
-- DBA ADVANCED OPTIMIZATION: PERFORMANCE INDEXES
----------------------------------------------------------------------
USE AlaaPearlDentalComplexDB;
GO

-- [1] Index for Appointment Date & Doctor (Speeds up doctor schedules and reports)
CREATE NONCLUSTERED INDEX IX_Appointment_Date_Doctor
ON Appointment (App_Date, Doctor_ID);
GO

-- [2] Index for Billing Status & Net Amount (Speeds up financial tracking and revenue queries)
CREATE NONCLUSTERED INDEX IX_Billing_Status_Amount
ON Billing (Status)
INCLUDE (Total_Amount, Discount);
GO

PRINT 'Success: Performance Indexes created successfully by DBA Alaa!';
GO