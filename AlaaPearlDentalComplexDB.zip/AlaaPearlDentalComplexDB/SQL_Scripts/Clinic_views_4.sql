----------------------------------------------------------------------
-- CLINIC VIEWS MANAGEMENT SCRIPT
----------------------------------------------------------------------
USE AlaaPearlDentalComplexDB;
GO

-- ===================================================================
-- [1] VIEW: DAILY APPOINTMENTS SCHEDULER
-- Purpose: Helps receptionist and doctors track patient appointments.
-- ===================================================================
CREATE VIEW v_Daily_Appointments AS
SELECT 
    A.App_ID,
    A.App_Date,
    A.App_Time,
    A.Status AS Appointment_Status,
    CONCAT(P.First_Name, ' ', P.Last_Name) AS Patient_Name,
    P.Phone_Num AS Patient_Phone,
    CONCAT(D_Staff.First_Name, ' ', D_Staff.Last_Name) AS Doctor_Name,
    R.Room_Num,
    R.Room_Type
FROM Appointment A
JOIN Patient P ON A.Patient_ID = P.Patient_ID
JOIN Doctor D ON A.Doctor_ID = D.Staff_ID
JOIN Staff D_Staff ON D.Staff_ID = D_Staff.Staff_ID
JOIN Clinic_Rooms R ON A.Room_ID = R.Room_ID;
GO

-- ===================================================================
-- [2] VIEW: FINANCIAL CLINIC SUMMARY
-- Purpose: Assists the medical accountant in monitoring payments & balances.
-- ===================================================================
CREATE VIEW v_Financial_Summary AS
SELECT 
    B.Bill_ID,
    B.Bill_Date,
    CONCAT(P.First_Name, ' ', P.Last_Name) AS Patient_Name,
    B.Total_Amount,
    B.Discount,
    B.Net_Amount, 
    B.Paid_Amount,
    B.Balance,    
    B.Status AS Payment_Status,
    CONCAT(A_Staff.First_Name, ' ', A_Staff.Last_Name) AS Accountant_Name
FROM Billing B
JOIN Appointment App ON B.Appointment_ID = App.App_ID
JOIN Patient P ON App.Patient_ID = P.Patient_ID
JOIN Staff A_Staff ON B.Staff_ID = A_Staff.Staff_ID;
GO

-- ===================================================================
-- [3] VIEW: PATIENT MEDICAL & TREATMENT HISTORY
-- Purpose: Provides doctors with full dental case details per patient.
-- ===================================================================
CREATE VIEW v_Patient_Treatment_History AS
SELECT 
    P.Patient_ID,
    CONCAT(P.First_Name, ' ', P.Last_Name) AS Patient_Name,
    A.App_Date AS Treatment_Date,
    TD.Tooth_Number,
    TD.Procedure_Type,
    TD.Cost AS Procedure_Cost,
    T.Treat_Plan_Name
FROM Treatment_Details TD
JOIN Appointment A ON TD.Appointment_ID = A.App_ID
JOIN Patient P ON A.Patient_ID = P.Patient_ID
JOIN Treatments T ON TD.Treat_ID = T.Treat_ID;
GO

-- ===================================================================
-- [4] VIEW: DENTAL LAB REQUESTS TRACKER
-- Purpose: Tracks external lab orders, dental crowns, and delivery status.
-- ===================================================================
CREATE VIEW v_Lab_Requests_Tracker AS
SELECT 
    LR.Request_ID,
    LR.Order_Date,
    LR.Expected_Delivery_Date,
    LR.Status AS Request_Status,
    L.Lab_Name,
    L.Phone_Num AS Lab_Phone,
    A.App_Date AS Appointment_Date,
    CONCAT(P.First_Name, ' ', P.Last_Name) AS Patient_Name
FROM Lab_Requests LR
JOIN Dental_Labs L ON LR.Lab_ID = L.Lab_ID
JOIN Appointment A ON LR.Appointment_ID = A.App_ID
JOIN Patient P ON A.Patient_ID = P.Patient_ID;
GO


----------------------------------------------------------------------
-- EXECUTION SECTION: FETCHING ALL VIEWS DATA
----------------------------------------------------------------------

-- 1. Display daily appointments and scheduler details
SELECT * FROM v_Daily_Appointments;

-- 2. Display the comprehensive financial and accountant summary
SELECT * FROM v_Financial_Summary;

-- 3. Display patient historical dental treatments
SELECT * FROM v_Patient_Treatment_History;

-- 4. Display log of dental external lab orders
SELECT * FROM v_Lab_Requests_Tracker;
GO