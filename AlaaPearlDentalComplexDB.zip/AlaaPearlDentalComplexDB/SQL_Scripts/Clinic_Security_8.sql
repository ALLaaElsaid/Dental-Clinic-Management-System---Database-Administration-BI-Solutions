----------------------------------------------------------------------
-- DATABASE SECURITY: ROLES, USERS, AND PRIVILEGES
----------------------------------------------------------------------
USE AlaaPearlDentalComplexDB;
GO

-- ===================================================================
-- [1] CREATE DATABASE ROLES
-- ===================================================================
-- Create specialized roles for clinic departments if they don't exist
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'Medical_Accountant_Role')
BEGIN
    CREATE ROLE Medical_Accountant_Role;
END

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'Receptionist_Role')
BEGIN
    CREATE ROLE Receptionist_Role;
END
GO

-- ===================================================================
-- [2] ASSIGN PRIVILEGES TO ROLES (GRANT & DENY)
-- ===================================================================

-- Accountant Role Privileges: Full access to financial tables, view only for patients
GRANT SELECT, INSERT, UPDATE ON Billing TO Medical_Accountant_Role;
GRANT SELECT, INSERT, UPDATE ON Patient_Payments TO Medical_Accountant_Role;
GRANT SELECT ON Patient TO Medical_Accountant_Role;
DENY DELETE ON Billing TO Medical_Accountant_Role; -- Security restriction

-- Receptionist Role Privileges: Management of patients and scheduling appointments
GRANT SELECT, INSERT, UPDATE ON Patient TO Receptionist_Role;
GRANT SELECT, INSERT, UPDATE ON Appointment TO Receptionist_Role;
GRANT SELECT ON Clinic_Rooms TO Receptionist_Role;
DENY SELECT, INSERT, UPDATE ON Billing TO Receptionist_Role; -- Cannot view financial data
GO

-- ===================================================================
-- [3] SIMULATION: CREATING USERS AND ASSIGNING THEM TO ROLES
-- ===================================================================

-- Create Logins at the SQL Server Instance level with strong passwords
CREATE LOGIN Receptionist_Login1 WITH PASSWORD = 'SecureRecPassword123!';
CREATE LOGIN Accountant_Login1 WITH PASSWORD = 'SecureAccPassword123!';
GO

-- Create corresponding Users inside the Clinic Database linked to those Logins
CREATE USER Mona_Receptionist FOR LOGIN Receptionist_Login1;
CREATE USER Ahmed_Accountant FOR LOGIN Accountant_Login1;
GO

-- Assign the Database Users as members to the specific roles Alaa created above
ALTER ROLE Receptionist_Role ADD MEMBER Mona_Receptionist;
ALTER ROLE Medical_Accountant_Role ADD MEMBER Ahmed_Accountant;
GO

PRINT 'Success: Server Logins and DB Users created and mapped to roles successfully!';
GO

PRINT 'Security configuration and roles defined successfully!';
GO