----------------------------------------------------------------------
-- 1. DATABASE CREATION
----------------------------------------------------------------------
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'AlaaPearlDentalComplexDB')
BEGIN
    DROP DATABASE AlaaPearlDentalComplexDB;
END
GO


CREATE DATABASE AlaaPearlDentalComplexDB;
GO

USE AlaaPearlDentalComplexDB;
GO

----------------------------------------------------------------------
-- 2. STAFF HIERARCHY (SUPERTYPE & SUBTYPES)
----------------------------------------------------------------------

-- [1] Supertype Table
CREATE TABLE Staff (
    Staff_ID INT IDENTITY(1,1) PRIMARY KEY,
    National_ID VARCHAR(14) NOT NULL UNIQUE,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    D_O_B DATE NOT NULL,      
    Gender CHAR(1) CHECK (Gender IN ('M', 'F')),
    Phone_Num VARCHAR(15),
    Email VARCHAR(100) UNIQUE,
    Salary DECIMAL(10,2) NOT NULL,
    Hire_Date DATE NOT NULL DEFAULT GETDATE(),
    Shift VARCHAR(20) NOT NULL CHECK (Shift IN ('Morning', 'Night', 'Evening')), 
    Type VARCHAR(50) NOT NULL CHECK (Type IN ('Doctor', 'Nurse', 'Receptionist', 'Sterilization_Officer', 'Medical_Accountant'))

);


-- [2] Subtype: Doctor
CREATE TABLE Doctor (
    Staff_ID INT PRIMARY KEY REFERENCES Staff(Staff_ID) ON DELETE CASCADE,
    License_Number VARCHAR(50) NOT NULL UNIQUE,
    Academic_Degree VARCHAR(50),
    Experience_Years INT DEFAULT 0
);

-- [3] Subtype: Receptionist
CREATE TABLE Receptionist (
    Staff_ID INT PRIMARY KEY REFERENCES Staff(Staff_ID) ON DELETE CASCADE,
    Receptionist_Code VARCHAR(20) NOT NULL UNIQUE,
    Computer_Skills VARCHAR(100),
    Language_Skills VARCHAR(100),
    Desk_Number VARCHAR(20)
);

-- [4] Subtype: Nurse
CREATE TABLE Nurse (
    Staff_ID INT PRIMARY KEY REFERENCES Staff(Staff_ID) ON DELETE CASCADE,
    Nursing_License VARCHAR(50) UNIQUE,
    Experience_Level VARCHAR(30),
    Clinic_Type VARCHAR(50)
);

-- [5] Subtype: Medical_Accountant
CREATE TABLE Medical_Accountant (
    Staff_ID INT PRIMARY KEY REFERENCES Staff(Staff_ID) ON DELETE CASCADE,
    Acc_Code VARCHAR(20) NOT NULL UNIQUE,
    Account_Level VARCHAR(50)
);

-- [6] Subtype: Sterilization_Officer
CREATE TABLE Sterilization_Officer (
    Staff_ID INT PRIMARY KEY REFERENCES Staff(Staff_ID) ON DELETE CASCADE,
    Sterilization_Cert VARCHAR(100),
    Shift_Type VARCHAR(20) CHECK (Shift_Type IN ('Morning', 'Night'))
);

-- [7] Table: Dental_Sterilization (Placed here as requested)
CREATE TABLE Dental_Sterilization (
    Ster_ID INT IDENTITY(1,1) PRIMARY KEY,
    Item_Name VARCHAR(100),
    Sterilization_Date DATETIME DEFAULT GETDATE(),
    Staff_ID INT REFERENCES Sterilization_Officer(Staff_ID)
);

----------------------------------------------------------------------
-- 3. CLINIC OPERATIONS & BRIDGE TABLES
----------------------------------------------------------------------

-- [8] Bridge: Doctor_Nurse_Assists
CREATE TABLE Doctor_Nurse_Assists (
    Doctor_ID INT REFERENCES Doctor(Staff_ID),
    Nurse_ID INT REFERENCES Nurse(Staff_ID),
    PRIMARY KEY (Doctor_ID, Nurse_ID)
);

-- [9] Table: Clinic_Rooms
CREATE TABLE Clinic_Rooms (
    Room_ID INT IDENTITY(1,1) PRIMARY KEY,
    Room_Num VARCHAR(10) NOT NULL UNIQUE,
    Status VARCHAR(20) DEFAULT 'Available' CHECK (Status IN ('Available', 'Occupied', 'Maintenance')),
    Room_Type VARCHAR(50),
    Equipment_List VARCHAR(250)
);

-- [10] Table: Specialization
CREATE TABLE Specialization (
    Spec_ID INT IDENTITY(1,1) PRIMARY KEY,
    Spec_Name VARCHAR(50) NOT NULL UNIQUE,
    Description VARCHAR(250)
);

-- [11] Bridge: Doctor_Specializations
CREATE TABLE Doctor_Specializations (
    Doctor_ID INT REFERENCES Doctor(Staff_ID) ON DELETE CASCADE,
    Spec_ID INT REFERENCES Specialization(Spec_ID) ON DELETE CASCADE,
    PRIMARY KEY (Doctor_ID, Spec_ID)
);

-- [12] Table: User_Shifts
CREATE TABLE User_Shifts (
    Shift_ID INT IDENTITY(1,1) PRIMARY KEY,
    Shift_Date DATE NOT NULL,
    Shift_Start_Time TIME NOT NULL,
    Shift_End_Time TIME NOT NULL,
    Staff_ID INT NOT NULL REFERENCES Staff(Staff_ID) ON DELETE CASCADE
);

----------------------------------------------------------------------
-- 4. PATIENT MANAGEMENT & MEDICAL RECORDS
----------------------------------------------------------------------

-- [13] Table: Insurance_Provider
CREATE TABLE Insurance_Provider (
    Provider_ID INT IDENTITY(1,1) PRIMARY KEY,
    Company_Name VARCHAR(100) NOT NULL UNIQUE,
    Corporate_Coverage DECIMAL(5,2) DEFAULT 0.00,
    Contact_Num VARCHAR(15)
);

-- [14] Table: Patient
CREATE TABLE Patient (
    Patient_ID INT IDENTITY(1,1) PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Gender CHAR(1) CHECK (Gender IN ('M', 'F')),
    DOB DATE NOT NULL, 
    Phone_Num VARCHAR(15) NOT NULL UNIQUE,
    Email VARCHAR(100),
    City VARCHAR(50), 
    Job VARCHAR(50),
    Provider_ID INT REFERENCES Insurance_Provider(Provider_ID) ON DELETE SET NULL
);

-- [15] Table: Medical_Conditions
CREATE TABLE Medical_Conditions (
    Condition_ID INT IDENTITY(1,1) PRIMARY KEY,
    Condition_Name VARCHAR(100) NOT NULL UNIQUE,
    Risk_Level VARCHAR(20) CHECK (Risk_Level IN ('Low', 'Medium', 'High')),
    Description VARCHAR(250)
);

-- [16] Bridge: Patient_Medical_Conditions
CREATE TABLE Patient_Medical_Conditions (
    Patient_ID INT REFERENCES Patient(Patient_ID) ON DELETE CASCADE,
    Condition_ID INT REFERENCES Medical_Conditions(Condition_ID) ON DELETE CASCADE,
    Notes VARCHAR(250), 
    Last_Update DATE NULL,
    PRIMARY KEY (Patient_ID, Condition_ID)
);

----------------------------------------------------------------------
-- 5. APPOINTMENTS, BILLING & TREATMENT
----------------------------------------------------------------------

-- [17] Table: Appointment
CREATE TABLE Appointment (
    App_ID INT IDENTITY(1,1) PRIMARY KEY,
    App_Date DATE NOT NULL,
    App_Time TIME NOT NULL,
    Status VARCHAR(20) DEFAULT 'Scheduled' CHECK (Status IN ('Scheduled', 'Completed', 'Canceled', 'No_Show')),
    Type VARCHAR(30) CHECK (Type IN ('Consultation', 'Follow-up', 'Procedure')),
    Duration INT DEFAULT 30, 
    Notes VARCHAR(500),
    Patient_ID INT NOT NULL REFERENCES Patient(Patient_ID), 
    Doctor_ID INT NOT NULL REFERENCES Doctor(Staff_ID),  
    Receptionist_ID INT REFERENCES Receptionist(Staff_ID),
    Room_ID INT NOT NULL REFERENCES Clinic_Rooms(Room_ID)
);

-- [18] Table: Billing
CREATE TABLE Billing (
    Bill_ID INT IDENTITY(1,1) PRIMARY KEY,
    Total_Amount DECIMAL(10,2) NOT NULL,
    Discount DECIMAL(10,2) DEFAULT 0.00,
    Net_Amount AS (Total_Amount - Discount) PERSISTED, 
    Paid_Amount DECIMAL(10,2) DEFAULT 0.00,
    Balance AS ((Total_Amount - Discount) - Paid_Amount) PERSISTED, 
    Status VARCHAR(20) DEFAULT 'Unpaid' CHECK (Status IN ('Unpaid', 'Partially_Paid', 'Fully_Paid')),
    Bill_Date DATE NOT NULL DEFAULT GETDATE(),
    Insurance_Coverage DECIMAL(10,2) DEFAULT 0.00,
    Appointment_ID INT NOT NULL REFERENCES Appointment(App_ID),
    Staff_ID INT NOT NULL REFERENCES Medical_Accountant(Staff_ID)
);

-- [19] Table: Patient_Payments
CREATE TABLE Patient_Payments (
    Payment_ID INT IDENTITY(1,1) PRIMARY KEY,
    Amount_Paid DECIMAL(10,2) NOT NULL,
    Payment_Date DATE NOT NULL DEFAULT GETDATE(),
    Payment_Method VARCHAR(30) CHECK (Payment_Method IN ('Cash', 'Credit_Card', 'Insurance', 'Installment_Plan')),
    Bill_ID INT NOT NULL REFERENCES Billing(Bill_ID) ON DELETE CASCADE
);

----------------------------------------------------------------------
-- 6. INVENTORY & LABS
----------------------------------------------------------------------

-- [20] Table: Medical_Supplies_Inventory
CREATE TABLE Medical_Supplies_Inventory (
    Item_ID INT IDENTITY(1,1) PRIMARY KEY,
    Item_Name VARCHAR(100) NOT NULL,
    Quantity_In_Stock INT NOT NULL DEFAULT 0 CHECK (Quantity_In_Stock >= 0),
    Quantity_In_Min INT NOT NULL DEFAULT 5, 
    Unit_Price DECIMAL(10,2) NOT NULL
);

-- [21] Table: Treatments
CREATE TABLE Treatments (
    Treat_ID INT IDENTITY(1,1) PRIMARY KEY,
    Treat_Plan_Name VARCHAR(100) NOT NULL,
    Total_Cost DECIMAL(10,2) NOT NULL
);

-- [22] Table: Treatment_Details
CREATE TABLE Treatment_Details (
    Detail_ID INT IDENTITY(1,1) PRIMARY KEY,
    Tooth_Number INT NOT NULL CHECK (Tooth_Number BETWEEN 1 AND 32), 
    Procedure_Type VARCHAR(100) NOT NULL,
    Cost DECIMAL(10,2) NOT NULL,
    Appointment_ID INT NOT NULL REFERENCES Appointment(App_ID) ON DELETE CASCADE,
    Treat_ID INT NOT NULL REFERENCES Treatments(Treat_ID)
);

-- [23] Bridge: Supplies_Details_Uses
CREATE TABLE Supplies_Details_Uses (
    Item_ID INT REFERENCES Medical_Supplies_Inventory(Item_ID) ON DELETE CASCADE,
    Detail_ID INT REFERENCES Treatment_Details(Detail_ID) ON DELETE CASCADE,
    Quantity_Used INT NOT NULL CHECK (Quantity_Used > 0),
    PRIMARY KEY (Item_ID, Detail_ID)
);

-- [24] Table: Dental_Labs
CREATE TABLE Dental_Labs (
    Lab_ID INT IDENTITY(1,1) PRIMARY KEY,
    Lab_Name VARCHAR(100) NOT NULL UNIQUE,
    Contact_Name VARCHAR(50),
    Phone_Num VARCHAR(15) NOT NULL,
    Email VARCHAR(100),
    City VARCHAR(50)
);

-- [25] Table: Lab_Requests
CREATE TABLE Lab_Requests (
    Request_ID INT IDENTITY(1,1) PRIMARY KEY,
    Order_Date DATE NOT NULL DEFAULT GETDATE(),
    Expected_Delivery_Date DATE,
    Actual_Delivery_Date DATE,
    Status VARCHAR(20) DEFAULT 'Pending' CHECK (Status IN ('Pending', 'Sent', 'Received', 'Canceled')),
    Appointment_ID INT NOT NULL REFERENCES Appointment(App_ID) ON DELETE CASCADE,
    Lab_ID INT NOT NULL REFERENCES Dental_Labs(Lab_ID)
);
GO