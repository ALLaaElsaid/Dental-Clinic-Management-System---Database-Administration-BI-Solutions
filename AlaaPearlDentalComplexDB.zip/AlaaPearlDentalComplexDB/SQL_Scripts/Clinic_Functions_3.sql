----------------------------------------------------------------------
-- CLINIC BUSINESS INTELLIGENCE: USER-DEFINED FUNCTIONS
----------------------------------------------------------------------
USE AlaaPearlDentalComplexDB;
GO

-- Drop existing functions if they exist for a clean overwrite
DROP FUNCTION IF EXISTS fn_CalculateNetSalary;
DROP FUNCTION IF EXISTS fn_GetDoctorAppointments;
GO

/*
===================================================================
[FUNCTION 1] SCALAR FUNCTION: NET SALARY CALCULATOR
Purpose: Calculates employee salary after a standard 10% deduction.
===================================================================
*/
CREATE FUNCTION fn_CalculateNetSalary (@GrossSalary DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @NetSalary DECIMAL(10,2);
    -- Deduct 10% from the original salary
    SET @NetSalary = @GrossSalary * 0.90;
    RETURN @NetSalary;
END;
GO

/*
===================================================================
[FUNCTION 2] TABLE-VALUED FUNCTION: DOCTOR APPOINTMENTS FILTER
Purpose: Returns a dynamic table containing all appointments for a specific doctor.
===================================================================
*/
CREATE FUNCTION fn_GetDoctorAppointments (@DoctorID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        A.App_ID,
        A.App_Date,
        A.App_Time,
        CONCAT(P.First_Name, ' ', P.Last_Name) AS Patient_Name,
        A.Room_ID
    FROM Appointment A
    JOIN Patient P ON A.Patient_ID = P.Patient_ID
    WHERE A.Doctor_ID = @DoctorID
);
GO


----------------------------------------------------------------------
-- EXECUTION SECTION: TESTING FUNCTIONS
----------------------------------------------------------------------

-- [TEST 1] Testing Scalar Function (fn_CalculateNetSalary)
-- Displays employee names, original salaries, and net salaries after deduction
SELECT 
    Staff_ID, 
    CONCAT(First_Name, ' ', Last_Name) AS Employee_Name, 
    Salary AS Gross_Salary,
    dbo.fn_CalculateNetSalary(Salary) AS Net_Salary
FROM Staff;

-- [TEST 2] Testing Table-Valued Function (fn_GetDoctorAppointments)
-- Fetches all appointments dynamically for Doctor with ID = 1
SELECT * FROM dbo.fn_GetDoctorAppointments(1);
GO