----------------------------------------------------------------------
-- CLINIC AUTOMATION: AUTOMATIC TRIGGERS SCRIPT
----------------------------------------------------------------------
USE AlaaPearlDentalComplexDB;
GO

/*
===================================================================
[TRIGGER 1] AUTOMATIC CLINIC ROOM OCCUPANCY
Purpose: Automatically changes clinic room status to 'Occupied' 
         whenever a new appointment is scheduled in that room.
===================================================================
*/
CREATE TRIGGER trg_UpdateRoomStatus
ON Appointment
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    
    UPDATE Clinic_Rooms
    SET Status = 'Occupied'
    FROM Clinic_Rooms R
    JOIN inserted i ON R.Room_ID = i.Room_ID
    WHERE i.Status = 'Scheduled';
END;
GO

/*
===================================================================
[TRIGGER 2] MEDICAL RECORD SECURITY LOCK
Purpose: Prevents any modifications to past appointments that 
         are already marked as 'Completed' or 'Canceled'.
===================================================================
*/
CREATE TRIGGER trg_PreventPastAppointmentChanges
ON Appointment
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 
        FROM deleted d
        WHERE d.Status IN ('Completed', 'Canceled')
    )
    BEGIN
        RAISERROR ('Security Violation: Completed or Canceled appointments cannot be modified!', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

/*
===================================================================
[TRIGGER 3] REAL-TIME INVENTORY DEDUCTION
Purpose: Automatically deducts the used dental materials from the 
         medical supplies warehouse when a treatment procedure ends.
===================================================================
*/
CREATE TRIGGER trg_UpdateInventoryOnUse
ON Supplies_Details_Uses
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Medical_Supplies_Inventory
    SET Quantity_In_Stock = Quantity_In_Stock - i.Quantity_Used
    FROM Medical_Supplies_Inventory MSI
    JOIN inserted i ON MSI.Item_ID = i.Item_ID;
END;
GO


----------------------------------------------------------------------
-- TESTING & EXECUTION SECTION: LIVE DEMO OF TRIGGERS
----------------------------------------------------------------------

-- [TEST 1] Testing Room Occupancy Trigger (trg_UpdateRoomStatus)
-- Check status of Room 'R4' before insert (Should be 'Available')
SELECT Room_Num, Status FROM Clinic_Rooms WHERE Room_Num = 'R4';

-- Insert a new appointment in Room 4 (Room_ID = 4)
INSERT INTO Appointment (App_Date, App_Time, Patient_ID, Doctor_ID, Receptionist_ID, Room_ID) 
VALUES ('2026-07-01', '12:00:00', 3, 2, 4, 4);

-- Check status of Room 'R4' after insert (Trigger should turn it into 'Occupied')
SELECT Room_Num, Status FROM Clinic_Rooms WHERE Room_Num = 'R4';


-- [TEST 2] Testing Inventory Deduction Trigger (trg_UpdateInventoryOnUse)
-- CRUCIAL STEP: Restock inventory first so we have enough items to deduct!
UPDATE Medical_Supplies_Inventory SET Quantity_In_Stock = 100 WHERE Item_ID = 1;

-- Check quantity of 'Gloves' (Item_ID = 1) before trigger execution (Should be 100)
SELECT Item_Name, Quantity_In_Stock FROM Medical_Supplies_Inventory WHERE Item_ID = 1;

-- Simulate doctor using 5 gloves in treatment detail 3
INSERT INTO Supplies_Details_Uses (Item_ID, Detail_ID, Quantity_Used) VALUES (1, 3, 5);

-- Check quantity after insert (Trigger should automatically subtract 5 gloves -> Result: 95)
SELECT Item_Name, Quantity_In_Stock FROM Medical_Supplies_Inventory WHERE Item_ID = 1;
GO