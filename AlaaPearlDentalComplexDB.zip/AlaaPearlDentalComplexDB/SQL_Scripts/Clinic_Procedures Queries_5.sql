----------------------------------------------------------------------
-- CLINIC BUSINESS LOGIC: STORED PROCEDURES SCRIPT (DYNAMIC STATUS FIXED)
----------------------------------------------------------------------
USE AlaaPearlDentalComplexDB;
GO

-- Drop existing procedures to ensure a clean overwrite
DROP PROCEDURE IF EXISTS sp_BookAppointment;
DROP PROCEDURE IF EXISTS sp_GenerateInvoice;
DROP PROCEDURE IF EXISTS sp_UpdatePatientDetails;
DROP PROCEDURE IF EXISTS sp_DBA_TakeFullBackup;
GO

/*
===================================================================
[PROCEDURE 1] SMART APPOINTMENT BOOKING
Purpose: Checks clinic room availability before booking a new appointment.
===================================================================
*/
CREATE PROCEDURE sp_BookAppointment
    @AppDate DATE,
    @AppTime TIME,
    @PatientID INT,
    @DoctorID INT,
    @ReceptionistID INT,
    @RoomID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 FROM Appointment 
        WHERE Room_ID = @RoomID AND App_Date = @AppDate AND App_Time = @AppTime
    )
    BEGIN
        RAISERROR ('Booking Conflict: The selected clinic room is already occupied at this time!', 16, 1);
        RETURN;
    END

    INSERT INTO Appointment (App_Date, App_Time, Patient_ID, Doctor_ID, Receptionist_ID, Room_ID)
    VALUES (@AppDate, @AppTime, @PatientID, @DoctorID, @ReceptionistID, @RoomID);

    PRINT 'Success: Appointment booked successfully!';
END;
GO

/*
===================================================================
[PROCEDURE 2] AUTOMATED INVOICE GENERATION
Purpose: Creates a bill for an appointment with a dynamic status parameter.
===================================================================
*/
CREATE PROCEDURE sp_GenerateInvoice
    @TotalAmount DECIMAL(10,2),
    @Discount DECIMAL(10,2),
    @AppointmentID INT,
    @AccountantID INT,
    @Status VARCHAR(20) -- Pass the exact accepted status by your check constraint
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Billing (Total_Amount, Discount, Appointment_ID, Staff_ID, Status)
    VALUES (@TotalAmount, @Discount, @AppointmentID, @AccountantID, @Status);

    PRINT 'Success: Invoice generated successfully!';
END;
GO

/*
===================================================================
[PROCEDURE 3] QUICK PATIENT PROFILE UPDATE
Purpose: Updates essential patient contact and insurance data.
===================================================================
*/
CREATE PROCEDURE sp_UpdatePatientDetails
    @PatientID INT,
    @NewPhone VARCHAR(15),
    @NewCity VARCHAR(50),
    @NewProviderID INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Patient
    SET Phone_Num = @NewPhone,
        City = @NewCity,
        Provider_ID = @NewProviderID
    WHERE Patient_ID = @PatientID;

    PRINT 'Success: Patient profile updated successfully!';
END;
GO

/*
===================================================================
[PROCEDURE 4] AUTOMATED SYSTEM FULL BACKUP (DBA MAINTENANCE)
Purpose: Generates a full database backup with a dynamic timestamp
         to the default secure SQL Server backup directory.
===================================================================
*/
CREATE PROCEDURE sp_DBA_TakeFullBackup
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @BackupPath NVARCHAR(500);
    DECLARE @FileDate NVARCHAR(20);

    -- Format the current timestamp as (YYYYMMDD_HHMMSS) to ensure unique file names
    SET @FileDate = CONVERT(NVARCHAR(20), GETDATE(), 112) + '_' + 
                    REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 108), ':', '');

    -- SECURE PATH: Using the universal default local path where SQL Server always has full access
    SET @BackupPath = 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Backup\AlaaPearlDental_Full_' + @FileDate + '.bak';

    -- Execute the SQL Server Backup command with Error Handling (TRY...CATCH)
    BEGIN TRY
        BACKUP DATABASE AlaaPearlDentalComplexDB
        TO DISK = @BackupPath
        WITH FORMAT,
             MEDIANAME = 'AlaaDentalBackups',
             NAME = 'Full Backup of AlaaPearlDentalComplexDB';

        PRINT '======================================================================';
        PRINT 'SUCCESS: Full Database Backup created successfully by DBA Alaa!';
        PRINT 'Backup File Location: ' + @BackupPath;
        PRINT '======================================================================';
    END TRY
    BEGIN CATCH
        -- If it still fails due to a different SQL Server version folder, fallback to default generic drive format
        SET @BackupPath = 'C:\AlaaPearlDental_Full_' + @FileDate + '.bak';
        
        BEGIN TRY
            BACKUP DATABASE AlaaPearlDentalComplexDB
            TO DISK = @BackupPath
            WITH FORMAT,
                 MEDIANAME = 'AlaaDentalBackups',
                 NAME = 'Full Backup of AlaaPearlDentalComplexDB';

            PRINT '======================================================================';
            PRINT 'SUCCESS (Fallback): Full Database Backup created successfully by DBA Alaa!';
            PRINT 'Backup File Location: ' + @BackupPath;
            PRINT '======================================================================';
        END TRY
        BEGIN CATCH
            PRINT '======================================================================';
            PRINT 'ERROR: Backup failed due to OS Permission constraints. Please check server rights.';
            PRINT ERROR_MESSAGE();
            PRINT '======================================================================';
        END CATCH
    END CATCH
END;
GO


----------------------------------------------------------------------
-- TESTING & EXECUTION SECTION: LIVE DEMO OF PROCEDURES
----------------------------------------------------------------------

-- [TEST 1] Testing Patient Profile Update (sp_UpdatePatientDetails)
SELECT Patient_ID, Phone_Num, City FROM Patient WHERE Patient_ID = 1;

EXEC sp_UpdatePatientDetails @PatientID = 1, @NewPhone = '01234567899', @NewCity = 'Cairo', @NewProviderID = 1;

SELECT Patient_ID, Phone_Num, City FROM Patient WHERE Patient_ID = 1;


-- [TEST 2] Testing Automated Invoice Generation (sp_GenerateInvoice)
EXEC sp_GenerateInvoice 
    @TotalAmount = 600, 
    @Discount = 50, 
    @AppointmentID = 5, 
    @AccountantID = 6, 
    @Status = 'Unpaid'; 

-- View the newly inserted invoice details
SELECT TOP 1 * FROM Billing ORDER BY Bill_ID DESC;
GO

-- [TEST 3] Testing Automated System Full Backup (sp_DBA_TakeFullBackup)
EXEC sp_DBA_TakeFullBackup;
GO