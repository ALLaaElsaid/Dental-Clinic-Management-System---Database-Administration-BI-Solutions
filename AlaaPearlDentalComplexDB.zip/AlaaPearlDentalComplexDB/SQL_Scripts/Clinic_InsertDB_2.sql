----------------------------------------------------------------------
-- DUMMY DATA INSERTION: THE FINAL CORRECTED MASTER SCRIPT
----------------------------------------------------------------------

-- [1] Staff Table (9 Rows in total - Generates Staff_ID from 1 to 9)
INSERT INTO Staff (National_ID, First_Name, Last_Name, D_O_B, Gender, Phone_Num, Email, Salary, Shift, Type) VALUES
('10000000000001', 'Staff_01', 'LN_01', '1985-01-01', 'M', '01000000001', 'staff1@dental.com', 5000, 'Morning', 'Doctor'),                -- ID: 1
('10000000000002', 'Staff_02', 'LN_02', '1990-01-01', 'F', '01000000002', 'staff2@dental.com', 4000, 'Morning', 'Doctor'),                -- ID: 2
('10000000000003', 'Staff_03', 'LN_03', '1992-01-01', 'F', '01000000003', 'staff3@dental.com', 3000, 'Evening', 'Nurse'),                 -- ID: 3
('10000000000004', 'Staff_04', 'LN_04', '1988-01-01', 'M', '01000000004', 'staff4@dental.com', 2500, 'Morning', 'Receptionist'),            -- ID: 4
('10000000000005', 'Staff_05', 'LN_05', '1995-01-01', 'M', '01000000005', 'staff5@dental.com', 2000, 'Night', 'Sterilization_Officer'),    -- ID: 5
('30000000000011', 'Staff_06', 'LN_06', '1990-05-15', 'M', '01000000011', 'accountant@dental.com', 3500, 'Morning', 'Medical_Accountant'), -- ID: 6
('40000000000012', 'Staff_07', 'LN_07', '1992-03-10', 'F', '01000000012', 'staff7@dental.com', 2700, 'Evening', 'Nurse'),                 -- ID: 7
('40000000000013', 'Staff_08', 'LN_08', '1989-11-22', 'M', '01000000013', 'staff8@dental.com', 4800, 'Morning', 'Doctor'),                -- ID: 8
('40000000000014', 'Staff_09', 'LN_09', '1995-07-05', 'F', '01000000014', 'staff9@dental.com', 2100, 'Night', 'Receptionist');             -- ID: 9


-- [2] Subtype: Doctor (References Staff IDs: 1, 2, 8)
INSERT INTO Doctor (Staff_ID, License_Number, Academic_Degree, Experience_Years) VALUES 
(1, 'LIC001', 'PhD', 10), 
(2, 'LIC002', 'MSc', 5),
(8, 'LIC013', 'PhD', 8);


-- [3] Subtype: Receptionist (References Staff IDs: 4, 9)
INSERT INTO Receptionist (Staff_ID, Receptionist_Code, Desk_Number) VALUES 
(4, 'REC01', 'D1'),
(9, 'REC03', 'D3');


-- [4] Subtype: Nurse (References Staff IDs: 3, 7)
INSERT INTO Nurse (Staff_ID, Nursing_License, Clinic_Type) VALUES 
(3, 'NUR01', 'General'),
(7, 'NUR03', 'Pediatric_Assist');


-- [5] Subtype: Medical_Accountant (References Staff ID: 6)
INSERT INTO Medical_Accountant (Staff_ID, Acc_Code, Account_Level) VALUES 
(6, 'ACC02', 'Senior');


-- [6] Subtype: Sterilization_Officer (References Staff ID: 5)
INSERT INTO Sterilization_Officer (Staff_ID, Sterilization_Cert, Shift_Type) VALUES 
(5, 'CERT01', 'Night');


-- [7] Table: Dental_Sterilization (References Sterilization_Officer ID: 5)
INSERT INTO Dental_Sterilization (Item_Name, Staff_ID) VALUES 
('Tools_Set_01', 5), ('Tools_Set_02', 5), ('Tools_Set_03', 5), ('Tools_Set_04', 5), ('Tools_Set_05', 5);


-- [8] Bridge: Doctor_Nurse_Assists (References Doctor: 1,2 and Nurse: 3,7)
INSERT INTO Doctor_Nurse_Assists (Doctor_ID, Nurse_ID) VALUES 
(1, 3), (2, 3), (8, 7), (1, 7), (2, 7);


-- [9] Table: Clinic_Rooms
INSERT INTO Clinic_Rooms (Room_Num, Room_Type) VALUES 
('R1', 'Exam'), ('R2', 'Surgery'), ('R3', 'Consult'), ('R4', 'X-Ray'), ('R5', 'Sterilization');


-- [10] Table: Specialization
INSERT INTO Specialization (Spec_Name) VALUES 
('Orthodontics'), ('Pediatric'), ('Surgery'), ('Periodontics'), ('Endodontics');


-- [11] Bridge: Doctor_Specializations (References Doctor: 1, 2 and Spec: 1, 2, 3, 5)
INSERT INTO Doctor_Specializations (Doctor_ID, Spec_ID) VALUES 
(1, 1), (1, 3), (2, 2), (2, 5), (8, 3);


-- [12] Table: User_Shifts (References Staff IDs: 1, 6)
INSERT INTO User_Shifts (Shift_Date, Shift_Start_Time, Shift_End_Time, Staff_ID) VALUES 
('2026-05-22', '08:00:00', '16:00:00', 1), 
('2026-05-22', '08:00:00', '16:00:00', 6),
('2026-05-23', '16:00:00', '00:00:00', 3),
('2026-05-23', '08:00:00', '16:00:00', 4),
('2026-05-23', '16:00:00', '00:00:00', 5);


-- [13] Table: Insurance_Provider
INSERT INTO Insurance_Provider (Company_Name) VALUES 
('Ins_A'), ('Ins_B'), ('Ins_C'), ('Ins_D'), ('Ins_E');


-- [14] Table: Patient (Generates Patient_ID from 1 to 8)
INSERT INTO Patient (First_Name, Last_Name, Gender, DOB, Phone_Num, City, Provider_ID) VALUES 
('Patient_01', 'LN_01', 'M', '1990-01-01', '01110000001', 'Damanhour', 1), -- ID: 1
('Patient_02', 'LN_02', 'F', '1995-01-01', '01110000002', 'Damanhour', 2), -- ID: 2
('Patient_03', 'LN_03', 'M', '1980-01-01', '01110000003', 'Alexandria', 1),-- ID: 3
('Patient_04', 'LN_04', 'F', '2000-01-01', '01110000004', 'Cairo', 3),     -- ID: 4
('Patient_05', 'LN_05', 'M', '1985-01-01', '01110000005', 'Tanta', 2),     -- ID: 5
('Patient_06', 'LN_06', 'F', '1992-04-12', '01110000006', 'Alexandria', 3),-- ID: 6
('Patient_07', 'LN_07', 'M', '1988-09-30', '01110000007', 'Cairo', 4),     -- ID: 7
('Patient_08', 'LN_08', 'F', '1998-12-15', '01110000008', 'Tanta', 1);     -- ID: 8


-- [15] Table: Medical_Conditions
INSERT INTO Medical_Conditions (Condition_Name, Risk_Level) VALUES 
('Diabetes', 'High'), ('Hypertension', 'Medium'), ('Allergy', 'Low'), ('Asthma', 'Medium'), ('Heart_Condition', 'High');


-- [16] Bridge: Patient_Medical_Conditions (References Patient: 1, 2, 3, 4, 5 and Condition: 1, 2, 3, 4, 5)
INSERT INTO Patient_Medical_Conditions (Patient_ID, Condition_ID) VALUES 
(1, 1), (2, 2), (3, 3), (4, 4), (5, 5);


-- [17] Table: Appointment (Generates App_ID from 1 to 5)
-- References Patient(1,2,6,7,8), Doctor(1,2,8), Receptionist(4), Room(1,2,3)
INSERT INTO Appointment (App_Date, App_Time, Patient_ID, Doctor_ID, Receptionist_ID, Room_ID) VALUES 
('2026-05-25', '10:00:00', 1, 1, 4, 1),  -- ID: 1
('2026-05-25', '11:00:00', 2, 2, 4, 2),  -- ID: 2
('2026-06-10', '09:30:00', 6, 8, 4, 1),  -- ID: 3
('2026-06-10', '14:00:00', 7, 8, 4, 2),  -- ID: 4
('2026-06-11', '10:00:00', 8, 1, 4, 3);  -- ID: 5


-- [18] Table: Billing (Generates Bill_ID from 1 to 5)
-- References Appointment(1,2,3,4,5) and Medical_Accountant(6)
INSERT INTO Billing (Total_Amount, Appointment_ID, Staff_ID) VALUES 
(500, 1, 6), 
(300, 2, 6), 
(400, 3, 6), 
(750, 4, 6), 
(250, 5, 6);


-- [19] Table: Patient_Payments (References Bill: 1, 2, 3, 4, 5)
INSERT INTO Patient_Payments (Amount_Paid, Bill_ID) VALUES 
(500, 1), (300, 2), (400, 3), (750, 4), (250, 5);


-- [20] Table: Medical_Supplies_Inventory
INSERT INTO Medical_Supplies_Inventory (Item_Name, Unit_Price) VALUES 
('Gloves', 50), ('Masks', 30), ('Anesthesia', 100), ('Fillings', 200), ('Floss', 20);


-- [21] Table: Treatments
INSERT INTO Treatments (Treat_Plan_Name, Total_Cost) VALUES 
('Cleaning', 200), ('Filling', 500), ('Root_Canal', 1000), ('Extraction', 300), ('Whitening', 800);


-- [22] Table: Treatment_Details (Generates Detail_ID from 1 to 5)
-- References Appointment(1, 2, 3, 4, 5) and Treatments(1, 2, 3, 4, 5)
INSERT INTO Treatment_Details (Tooth_Number, Procedure_Type, Cost, Appointment_ID, Treat_ID) VALUES 
(15, 'Cleaning', 200, 1, 1), 
(20, 'Filling', 500, 2, 2),
(5, 'Root_Canal', 1000, 3, 3),
(30, 'Extraction', 300, 4, 4),
(10, 'Whitening', 800, 5, 5);


-- [23] Bridge: Supplies_Details_Uses (References Inventory: 1,2,3,4,5 and Details: 1,2,3,4,5)
INSERT INTO Supplies_Details_Uses (Item_ID, Detail_ID, Quantity_Used) VALUES 
(1, 1, 2), (2, 2, 1), (3, 3, 1), (4, 4, 1), (5, 5, 1);


-- [24] Table: Dental_Labs
INSERT INTO Dental_Labs (Lab_Name, Phone_Num) VALUES 
('Lab_01', '01200000001'), ('Lab_02', '01200000002'), ('Lab_03', '01200000003'), ('Lab_04', '01200000004'), ('Lab_05', '01200000005');


-- [25] Table: Lab_Requests (References Appointment: 1, 3, 4 and Labs: 1, 2, 3)
INSERT INTO Lab_Requests (Appointment_ID, Lab_ID) VALUES 
(1, 1), (3, 2), (4, 3), (2, 4), (5, 5);
GO
----------------------------------------------------------------------
-- EXECUTION SECTION: FETCHING AND VERIFYING ALL INSERTED DATA
----------------------------------------------------------------------

-- [1] Core HR & Subtype Tables
SELECT * FROM Staff;
SELECT * FROM Doctor;
SELECT * FROM Receptionist;
SELECT * FROM Nurse;
SELECT * FROM Medical_Accountant;
SELECT * FROM Sterilization_Officer;

-- [2] Clinic Infrastructure & Specializations
SELECT * FROM Clinic_Rooms;
SELECT * FROM Specialization;
SELECT * FROM Doctor_Specializations;
SELECT * FROM Doctor_Nurse_Assists;
SELECT * FROM User_Shifts;

-- [3] Patients & Medical Records
SELECT * FROM Insurance_Provider;
SELECT * FROM Patient;
SELECT * FROM Medical_Conditions;
SELECT * FROM Patient_Medical_Conditions;

-- [4] Operations & Appointments
SELECT * FROM Appointment;
SELECT * FROM Treatment_Details;
SELECT * FROM Treatments;

-- [5] Finance & Payments
SELECT * FROM Billing;
SELECT * FROM Patient_Payments;

-- [6] Logistics, Inventory & External Labs
SELECT * FROM Medical_Supplies_Inventory;
SELECT * FROM Supplies_Details_Uses;
SELECT * FROM Dental_Sterilization;
SELECT * FROM Dental_Labs;
SELECT * FROM Lab_Requests;
GO